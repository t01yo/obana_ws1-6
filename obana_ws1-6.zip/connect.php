<?php

    $host = "localhost";
    $username = "root";
    $password = "";
    $db_name = "migration";

    // $connection = new mysqli($host, $username, $password, $db_name);
    $con = new mysqli($host, $username, $password, $db_name);


?>